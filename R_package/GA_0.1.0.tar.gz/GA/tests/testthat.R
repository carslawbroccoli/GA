library(testthat)
library(GA)

test_check("GA")
source('./GA/tests/test.R')
source('./GA/tests/test_training_with_fake_data.R')
source('./GA/tests/test_GeneticAlgorithm.R')
